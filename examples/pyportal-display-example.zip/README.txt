PyPortal Display: files for your CIRCUITPY drive
================================================

Made with PyPortal Display Designer. Exported 10/19/2026, 1:03:11 PM.

1. Install CircuitPython 9 or newer on the PyPortal (boot_out.txt shows the version)
   https://circuitpython.org/board/pyportal/  (use the PyPortal Titano or
   Pynt page instead if that is your board; this layout is for 320x240).

2. Copy everything in this folder onto the CIRCUITPY drive:
     code.py         the program
     config.json     your layout, colors, weekly schedule and timing
     settings.toml   WiFi name/password and OpenWeatherMap key
     fonts/          7 bitmap fonts made from your design
     images/         2 pictures (320x240, 24-bit BMP)

3. Open settings.toml in a text editor and fill in:
     CIRCUITPY_WIFI_SSID, CIRCUITPY_WIFI_PASSWORD, OPENWEATHER_KEY
   Get a free key at https://openweathermap.org/api (Current Weather Data).

4. Add these libraries to CIRCUITPY/lib from the bundle matching your CircuitPython version
   (https://circuitpython.org/libraries), or run:
     circup install adafruit_esp32spi adafruit_requests adafruit_connection_manager adafruit_display_text adafruit_bitmap_font

     adafruit_esp32spi/          (WiFi co-processor)
     adafruit_requests.mpy
     adafruit_connection_manager.mpy
     adafruit_display_text/
     adafruit_bitmap_font/
     adafruit_bus_device/        (needed by adafruit_esp32spi)
     adafruit_ticks.mpy          (needed by adafruit_display_text)

The clock is set from the OpenWeatherMap request using your zip code's
time zone, so it is correct once WiFi connects. Without WiFi settings the
screen still runs, but the clock starts at midnight and weather shows "--".

Changing the design later: edit it in the designer and export again. If only
the schedule, colors or timing changed, copying the new config.json is enough
(also copy fonts/ if you changed a font or size, and images/ if photos changed).

Troubleshooting: connect to the PyPortal's serial console (Mu editor or
https://code.circuitpython.org) to see messages such as "WiFi failed" or
"OpenWeatherMap: Invalid API key".
